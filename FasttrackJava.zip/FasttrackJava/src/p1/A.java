package p1;

public class A {
private void display()
{
	System.out.println("Tns");
}
}
