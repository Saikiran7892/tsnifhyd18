package com.si.day1;

public class Basic {
	public static void main(String[] args) {
	 System.out.println("Hello world!");
	}
	
}
